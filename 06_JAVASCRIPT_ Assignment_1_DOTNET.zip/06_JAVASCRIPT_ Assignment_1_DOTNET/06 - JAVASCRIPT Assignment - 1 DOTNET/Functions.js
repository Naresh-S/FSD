﻿//1. Write a JavaScript program to display the current day and time in the following format. 
function GetCurrentDateTime() {
    var d = new Date();
    var days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return "<p>Today is: " + days[d.getDay()] + "</p><p>Current Time is: " + formatAMPM(d) + "</p>";
}
function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var Seconds = date.getSeconds()
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    var strTime = hours + ampm + ':' + ' ' + minutes + ':' + ' ' + Seconds;
    return strTime;
}
//2.Write a JavaScript program to print the contents of the current window.
function printContents() {
    window.print();
}
//3.Write a JavaScript program to get the current date. Expected Output:mm-dd-yyyy,mm/dd/yyyy or dd-mm-yyyy, dd/mm/yyyy
function GetFormattedDateTime() {
    var d = new Date();
    var month = d.getMonth();
    if (month < 10)
        month = "0" + month
    var date = d.getDate();
    if (date < 10)
        date = "0" + date
    var Year = d.getFullYear();
    var Format1 = month + '-' + date + '-' + Year;
    var Format2 = month + '/' + date + '/' + Year;
    var Format3 = date + '-' + month + '-' + Year;
    var Format4 = date + '/' + month + '/' + Year;
    return "<p>mm-dd-yyyy is: " + Format1 + "</p><p>mm/dd/yyyy is: " + Format2 + "</p><p>dd-mm-yyyy is: " + Format3 + "</p><p>dd/mm/yyyy is: " + Format4 + "</p>"

}
//4.Write a JavaScript program where the program takes a random integer between 1 to 10, the user is then prompted to input a guess number. If the user input matches with guess number, the program will display a message "Good Work" otherwise display a message "Not matched".
function GetRandomNumber(txtRandom) {
    var txtRandom = document.getElementById(txtRandom)
    if (txtRandom.value == Math.floor((Math.random() * 10) + 1))
        alert("Good Work");
    else
        alert("Not matched");
}
///5.Write a JavaScript program to calculate multiplication and division of two numbers (input from user). 
function Multiply(firstnum, secondnum, divresult) {
    var firstnumber = document.getElementById(firstnum);
    var secondnumber = document.getElementById(secondnum);
    var diresult = document.getElementById(divresult);
    diresult.innerHTML = "The Result is: " + firstnumber.value * secondnumber.value;
}
function Divide(firstnum, secondnum, divresult) {
    var firstnumber = document.getElementById(firstnum);
    var secondnumber = document.getElementById(secondnum);
    var diresult = document.getElementById(divresult);
    diresult.innerHTML = "The Result is: " + firstnumber.value / secondnumber.value;
}
//7. Write a JavaScript program to capitalize the first letter of each word of a given string.
function CapitalizeTheLetter(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);
    str = str.split(" ");
    for (var i = 0, x = str.length; i < x; i++) {
        str[i] = str[i][0].toUpperCase() + str[i].substr(1);
    }
    lblString.innerHTML = "The Result is: " + str.join(" ");
}
//8.Write a JavaScript program to check if a given string contains equal number of p's and s's present.
function EqualPS(string, lblstroutput) {
    var str = document.getElementById(string).value.toUpperCase();
    var lblString = document.getElementById(lblstroutput);
    var str_P = str.replace(/[^P]/g, "");
    var str_S = str.replace(/[^S]/g, "");
    var P_num = str_P.length;
    var S_num = str_S.length;
    if (P_num === S_num)
        lblString.innerHTML = "The Result is: " + "True";
    else
        lblString.innerHTML = "The Result is: " + "False";


}
//9.Write a JavaScript program to create a new string of 4 copies of the last 3 characters of a given original string. The length of the given string must be 3 and above.
function Create4Copies(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);
    if (str.length >= 3) {
        result_str = str.substring(str.length - 3);
        lblString.innerHTML = "The Result is: " + result_str + result_str + result_str + result_str;
    }
    else
        lblString.innerHTML = "The Result is: " + "False";
}
//10.Write a JavaScript program to swap the first and last elements of a given array of integers. The array length should be at least 1.
function swapArray(string, lblstroutput) {
    var arra = [];
    arra = document.getElementById(string).value.split("");
    var lblString = document.getElementById(lblstroutput);
    if (arra != null && arra.length > 1) {
        var temp = arra[0];
        arra[0] = arra[arra.length - 1];
        arra[arra.length - 1] = temp;
    }
    lblString.innerHTML = arra.join("");;
}
//11.Write a JavaScript function that reverse a number.Using built in functions.
function ReverseANumber(Number, lblstroutput) {
    var num = document.getElementById(Number).value;
    var lblString = document.getElementById(lblstroutput);
    num = num + "";
    lblString.innerHTML = num.split("").reverse().join("");
}
//12.Write a JavaScript function that returns a passed string with letters in alphabetical order. Using built in functions.
function StringAlfabetOrder(string, lblstroutput) {
    var str = document.getElementById(string).value.toLowerCase();
    var lblString = document.getElementById(lblstroutput);
    lblString.innerHTML = "The Result is: " + str.split('').sort().join('');
}
//13.a.Write a JavaScript function that accepts a string as a parameter and find the longest word within the string.
function FindLongestWord(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);
    var array1 = str.match(/\w[a-z]{0,}/gi);
    var result = array1[0];
    for (var x = 1 ; x < array1.length ; x++) {
        if (result.length < array1[x].length) {
            result = array1[x];
        }
    }
    lblString.innerHTML = result;
}
//13 b.Write a JavaScript function to extract unique characters from a string.
function GetUniqueCharcters(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);

    var uniql = "";
    for (var x = 0; x < str.length; x++) {

        if (uniql.indexOf(str.charAt(x)) == -1) {
            uniql += str[x];

        }
    }
    lblString.innerHTML = "The Result is:" + uniql;
}
//13 c.Write a JavaScript function to get the number of occurrences of each letter in specified string.
function GetNumberofOccurences(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);
    var uchars = {};
    str.replace(/\S/g, function (l) { uchars[l] = (isNaN(uchars[l]) ? 1 : uchars[l] + 1); });
    lblString.innerHTML = "The Results is:" + JSON.stringify(uchars);
}
//14.Write a JavaScript function that generates a string id (specified length) of random character
function GetSpecificLenString(string, lblstroutput) {
    var str = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);
    var text = "";
    var l = 8;
    for (var i = 0; i < l; i++) {
        text += str.charAt(Math.floor(Math.random() * str.length));
    }
    lblString.innerHTML = "The Results is:" + text;
}
//15. Write a JavaScript function to find longest substring in a given a string without repeating characters
function LongestSubstring(string, lblstroutput) {

    var input = document.getElementById(string).value;
    var lblString = document.getElementById(lblstroutput);

    var chars = input.split('');
    var curr_char;
    var str = "";
    var longest_string = "";
    var hash = {};
    for (var i = 0; i < chars.length; i++) {
        curr_char = chars[i];
        if (!hash[chars[i]]) {
            str += curr_char;
            hash[chars[i]] = { index: i };
        }
        else {
            if (longest_string.length <= str.length) {
                longest_string = str;
            }
            var prev_dupeIndex = hash[curr_char].index;
            var str_FromPrevDupe = input.substring(prev_dupeIndex + 1, i);
            str = str_FromPrevDupe + curr_char;
            hash = {};
            for (var j = prev_dupeIndex + 1; j <= i; j++) {
                hash[input.charAt(j)] = { index: j };
            }
        }
    }
    if (longest_string.length > str.length)
        lblString.innerHTML = "The Results is: " + longest_string;
    else
        lblString.innerHTML = "The Results is: " + str;
}
//16.Write a JavaScript function to get the values of First and Last name of the following form.
function getFormvalue() {
    var x = document.getElementById("form1");
    var Result = ""
    for (var i = 0; i < x.length; i++) {
        if (x.elements[i].value != 'Submit') {
            Result += (x.elements[i].name + " : " + x.elements[i].value + " \n");
        }
    }
    alert(Result);
}
//17.Here is a sample html file with a submit button. Write a JavaScript function to get the value of the href, hreflang, rel,target, and type attributes of the specified link
function getAttributes() {
    var Anchor = document.getElementById("w3r");
    alert("href: " + Anchor.href + "\n" + "hreflang: " + Anchor.hreflang + "\n" + "rel: " + Anchor.rel + "\n" + "target: " + Anchor.target + "\n" + "type: " + Anchor.type);
}
//18.Write a JavaScript function to add rows to a table.Sample HTML file
function insert_Row() {
    var table = document.getElementById("sampleTable");
    var x = table.insertRow()
    x.insertCell(0).innerHTML = "Row" + table.rows.length + " cell1";
    x.insertCell(1).innerHTML = "Row" + table.rows.length + " cell2";

}
//19.Write a JavaScript function that accept row, column, (to identify a particular cell) and a string to update the content of that cell.Sample HTML file :
function changeContent() {
    row = window.prompt("Input the Row number(0,1,2)", "0");
    col = window.prompt("Input the Column number(0,1)", "0");
    text = window.prompt("Input the Cell content");
    var x = document.getElementById('myTable').rows[parseInt(row, 10)].cells;
    x[parseInt(col, 10)].innerHTML = text;

}
//20.Write a JavaScript program to remove items from a dropdown list.
function removecolor() {
    var dropdown = document.getElementById("colorSelect");
    if (dropdown.length > 0) {
        dropdown.remove(0);
    }
}